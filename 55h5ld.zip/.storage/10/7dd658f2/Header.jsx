// src/components/Header.jsx
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const links = [
    { path: '/', text: 'About' },
    { path: '/services', text: 'Services' },
    { path: '/contact', text: 'Contact' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <nav className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="font-lora text-2xl font-semibold">
            Maison Adrian
          </Link>

          <div className="flex items-center">
            {/* Desktop menu */}
            <div className="hidden md:flex space-x-8 mr-6">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`font-roboto ${
                    isActive(link.path)
                      ? 'text-gray-900 font-medium'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {link.text}
                </Link>
              ))}
            </div>
            
            {/* CTA Button */}
            <a 
              href="mailto:adrian@maisonadrian.com" 
              className="hidden md:block bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-md font-medium transition-colors duration-200"
            >
              Let's work together
            </a>

            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block font-roboto ${
                  isActive(link.path)
                    ? 'text-gray-900 font-medium'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.text}
              </Link>
            ))}
            <a 
              href="mailto:adrian@maisonadrian.com" 
              className="block mt-6 bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded-md font-medium text-center transition-colors duration-200"
            >
              Let's work together
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}

export default Header;