// src/pages/About.jsx
import React from 'react';

function About() {
  return (
    <article className="max-w-3xl mx-auto">
      <section className="mb-16">
        <h1 className="font-serif text-4xl mb-8 font-semibold text-warm-gray-900">About</h1>
        <div className="space-y-6 font-sans">
          <h2 className="text-3xl font-serif font-medium text-warm-gray-900">Hi, I'm Adrian – your strategic wordsmith.</h2>
          <p className="text-xl leading-relaxed text-warm-gray-800">
            I help DTC brands connect and convert through sharp, emotionally intelligent copy.
          </p>
          <p className="text-xl leading-relaxed text-warm-gray-800">
            From email flows and landing pages to ad creatives and brand voice strategy – I write words that move people to act.
          </p>
          <p className="text-lg leading-relaxed mt-8 text-warm-gray-700">
            With a background in e-commerce and storytelling, I've worked with bold, design-led brands to build loyalty, boost engagement, and ultimately drive sales.
          </p>
        </div>
      </section>
      
      <section id="services" className="mb-16">
        <h2 className="font-serif text-3xl mb-6 font-semibold text-warm-gray-900">What I Offer</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Website Copy</h3>
            <p className="font-sans text-warm-gray-700">Homepages, Landing Pages, Product Pages</p>
          </div>
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Email Marketing</h3>
            <p className="font-sans text-warm-gray-700">Welcome Series, Flows, Launch Sequences</p>
          </div>
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Product Descriptions</h3>
            <p className="font-sans text-warm-gray-700">eCommerce, marketplaces</p>
          </div>
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Social Media Copy</h3>
            <p className="font-sans text-warm-gray-700">Captions, Ad Creatives, Organic Posts</p>
          </div>
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Brand Voice Guidelines</h3>
            <p className="font-sans text-warm-gray-700">Tone of voice development and documentation</p>
          </div>
          <div className="border-l-2 border-warm-gray-800 pl-6 py-2">
            <h3 className="font-serif text-xl mb-2 text-warm-gray-900">Copy Audits & Strategy</h3>
            <p className="font-sans text-warm-gray-700">Consulting and optimization of existing copy</p>
          </div>
        </div>
      </section>
      
      <section className="mb-16">
        <h2 className="font-serif text-3xl mb-8 font-semibold text-warm-gray-900">Client Testimonials</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-warm-white border border-warm-gray-200 p-6 rounded-lg">
            <p className="font-sans italic text-warm-gray-700 mb-6">
              "Adrian's work on our email campaigns transformed our customer engagement. His copy not only captures our brand voice perfectly but has directly contributed to a 32% increase in open rates."
            </p>
            <div className="flex items-center">
              <div>
                <p className="font-medium text-warm-gray-900">Sarah Johnson</p>
                <p className="text-warm-gray-600 text-sm">Marketing Director, Formulated For</p>
              </div>
            </div>
          </div>
          <div className="bg-warm-white border border-warm-gray-200 p-6 rounded-lg">
            <p className="font-sans italic text-warm-gray-700 mb-6">
              "Working with Adrian was a game-changer for our product descriptions. His ability to highlight benefits while maintaining our brand's distinctive voice led to a significant improvement in conversion rates."
            </p>
            <div className="flex items-center">
              <div>
                <p className="font-medium text-warm-gray-900">Michael Chen</p>
                <p className="text-warm-gray-600 text-sm">Founder, SecondSkin</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <div className="my-16 text-center">
        <a 
          href="mailto:maisonadrian@gmx.de" 
          className="inline-block bg-accent hover:bg-accent-dark text-white px-8 py-3 rounded-md font-medium text-lg transition-colors duration-200"
        >
          Let's work together
        </a>
      </div>
    </article>
  );
}

export default About;