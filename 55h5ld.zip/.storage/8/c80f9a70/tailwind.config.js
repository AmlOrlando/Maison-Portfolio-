/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        'warm-white': '#FAF9F7',
        'warm-gray': {
          100: '#F5F3F0',
          200: '#E8E6E1',
          300: '#D3CEC4',
          400: '#B8B2A7',
          500: '#A39E93',
          600: '#857F72',
          700: '#625D52',
          800: '#504A40',
          900: '#423D33'
        },
        'accent': {
          light: '#D4C9BD',
          DEFAULT: '#A67F5D',
          dark: '#8B6B4E'
        }
      },
      fontFamily: {
        'sans': ['Inter', 'sans-serif'],
        'serif': ['Fraunces', 'serif']
      }
    },
  },
  plugins: [],
}