// src/components/Footer.jsx
import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link to="/" className="font-lora text-xl">
              Maison Adrian
            </Link>
            <p className="mt-2 text-sm text-gray-600">
              Strategic copywriting for bold DTC brands
            </p>
          </div>
          <div className="flex flex-col md:flex-row md:space-x-8">
            <div className="mb-4 md:mb-0">
              <h3 className="font-medium text-sm uppercase tracking-wider text-gray-700 mb-2">Services</h3>
              <div className="flex flex-col space-y-1">
                <Link to="/services" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Website Copy</Link>
                <Link to="/services" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Email Marketing</Link>
                <Link to="/services" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Brand Voice</Link>
              </div>
            </div>
            <div>
              <h3 className="font-medium text-sm uppercase tracking-wider text-gray-700 mb-2">Connect</h3>
              <div className="flex flex-col space-y-1">
                <a
                  href="mailto:adrian@maisonadrian.com"
                  className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Email
                </a>
                <a
                  href="https://instagram.com/Maison_Adrian"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Instagram
                </a>
                <Link
                  to="/contact"
                  className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Contact
                </Link>
              </div>
            </div>
          </div>
          <div className="mt-6 md:mt-0 text-sm text-gray-500">
            © {new Date().getFullYear()} Maison Adrian
          </div>
        </div>
      </div>
    </footer>
  );
}
}

export default Footer;