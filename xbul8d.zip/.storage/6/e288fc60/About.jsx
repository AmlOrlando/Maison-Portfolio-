// src/pages/About.jsx
import React from 'react';

function About() {
  return (
    <article className="max-w-3xl mx-auto">
      <h1 className="font-lora text-4xl mb-8 font-semibold">About Maisonadrian</h1>
      <div className="space-y-6 font-roboto">
        <p className="text-lg leading-relaxed">
          In a world where attention spans grow ever shorter, the power of the written word lies not in its length but in its impact. Maisonadrian does not simply write; Maisonadrian crafts messages that resonate deeply with the reader, transforming mere thoughts into powerful catalysts for action.
        </p>
        <p className="text-lg leading-relaxed">
          Writing is an art—one that shapes how we perceive the world, how we communicate with one another, and how we define our brands. Words are the silent architects of thought and perception. In this craft, I find my purpose.
        </p>
        <div className="mt-12">
          <h2 className="font-lora text-2xl mb-4">Core Services</h2>
          <ul className="list-none space-y-2">
            <li className="flex items-center">
              <span className="w-2 h-2 bg-gray-800 rounded-full mr-3"></span>
              Social Media Captions
            </li>
            <li className="flex items-center">
              <span className="w-2 h-2 bg-gray-800 rounded-full mr-3"></span>
              Newsletters
            </li>
            <li className="flex items-center">
              <span className="w-2 h-2 bg-gray-800 rounded-full mr-3"></span>
              Story Editing
            </li>
            <li className="flex items-center">
              <span className="w-2 h-2 bg-gray-800 rounded-full mr-3"></span>
              SEO Titles
            </li>
          </ul>
        </div>
      </div>
    </article>
  );
}

export default About;
