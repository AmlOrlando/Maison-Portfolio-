// src/pages/Services.jsx
import React from 'react';

function Services() {
  const services = [
    {
      title: "Social Media Captions",
      description: "Crafting concise, compelling, and brand-consistent captions that drive engagement and form connections."
    },
    {
      title: "Newsletters",
      description: "Writing thought-provoking and action-driven newsletters that engage readers emotionally and intellectually."
    },
    {
      title: "Story Editing",
      description: "Editing and curating social media stories, refining them for clarity, tone, and emotional impact."
    },
    {
      title: "SEO Title Writing",
      description: "Creating SEO-optimized titles that not only rank well but also engage and captivate human readers."
    }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="font-lora text-4xl mb-8 font-semibold">Services</h1>
      <p className="text-lg mb-12 font-roboto leading-relaxed">
        Writing is not just about putting words on paper; it is about creating meaning, context, and connection. At Maisonadrian, we understand that the right words can bridge the gap between a brand's vision and its audience's needs. Each caption, each newsletter, and each SEO title is crafted with the precision of a sculptor shaping marble—stripped of all excess and focused entirely on the emotional and intellectual impact it will leave behind.
      </p>
      <div className="grid gap-8">
        {services.map((service, index) => (
          <div key={index} className="border-l-2 border-gray-800 pl-6 py-2">
            <h2 className="font-lora text-2xl mb-2">{service.title}</h2>
            <p className="font-roboto text-gray-700">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Services;
