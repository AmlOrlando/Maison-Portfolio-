// src/pages/Portfolio.jsx
import React from 'react';

function Portfolio() {
  const examples = [
    {
      type: "Social Media Caption",
      content: "Embrace the silence between the words. It's in these moments that true meaning takes shape. #BrandStorytelling #CopywritingArt"
    },
    {
      type: "Newsletter Excerpt",
      content: "In this month's deep dive, we explore how language shapes perception and how carefully chosen words can transform your brand's narrative..."
    },
    {
      type: "SEO Title",
      content: "Transformative Brand Storytelling: Crafting Narratives That Resonate | Industry Insights"
    }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="font-lora text-4xl mb-8 font-semibold">Portfolio</h1>
      <div className="space-y-12">
        {examples.map((example, index) => (
          <div key={index} className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-lora text-xl mb-3">{example.type}</h3>
            <p className="font-roboto text-gray-700 italic">{example.content}</p>
          </div>
        ))}
      </div>
      <div className="mt-12 text-center">
        <a 
          href="https://instagram.com/Maison_Adrian" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-block bg-gray-900 text-white px-6 py-3 rounded font-roboto hover:bg-gray-800 transition-colors"
        >
          View More Work on Instagram
        </a>
      </div>
    </div>
  );
}

export default Portfolio;
